Local shell render package.
Open episode markdown in any editor, or plug into Remotion later.
